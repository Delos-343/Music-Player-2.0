# Music Player 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/zYPxVYN](https://codepen.io/Delos_343/pen/zYPxVYN).

